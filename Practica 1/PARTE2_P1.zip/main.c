#include <stdio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <driver/gpio.h>
#include "esp_timer.h"

int botones[] = {21,19};
int leds[]={25,26,27};

QueueHandle_t handlerQueue;
uint64_t time_aux = 0;

static void IRAM_ATTR gpio_interrupt_handler(void *args){
    int pinNumber = (int)args;
    uint64_t time = esp_timer_get_time() / 1000;
    if(time - time_aux > 100 ){

      time_aux = time;
      xQueueSendFromISR(handlerQueue, &pinNumber, NULL);
    }
    
}

void init_gpio(void){
  gpio_install_isr_service(0);

  //configuracion de botones
  for(int i = 0; i < 2; i++){
    gpio_reset_pin(botones[i]);
    gpio_set_direction(botones[i],GPIO_MODE_INPUT);
    gpio_pulldown_en(botones[i]);
    gpio_pullup_dis(botones[i]);

    // IMPORTANTE: ANYEDGE para detectar presionar y soltar
    gpio_set_intr_type(botones[i], GPIO_INTR_POSEDGE);

    // pasamos 'i' como argumento para saber que indice de arreglo es
    gpio_isr_handler_add(botones[i],gpio_interrupt_handler,(void *)i);
  }

  //configuracion de leds
  for(int i =0; i < 3;i++){
    gpio_reset_pin(leds[i]);
    gpio_set_direction(leds[i],GPIO_MODE_OUTPUT);
    gpio_set_level(leds[i],0);
  }
  gpio_set_level(leds[0],1);
}

void LED_Control_Task(void *params){
    int pinNumber, bandera = 0, esperando = 0;
    while(true){
        if (bandera == 0 && esperando == 0){
            printf ("Esperando vehiculo\n");
            esperando = 1;
        }
        if (xQueueReceive(handlerQueue, &pinNumber, portMAX_DELAY))
        {
           vTaskDelay ( 20 / portTICK_PERIOD_MS);

           switch(pinNumber){
            case 0:
            if ( bandera == 0){
            printf("Elevando barrera\n");
            gpio_set_level(leds[0],0);
            gpio_set_level(leds[1],1);
            vTaskDelay (1000 / portTICK_PERIOD_MS);
            
            gpio_set_level(leds[1],0);
            gpio_set_level(leds[2],1);
            vTaskDelay (1000 / portTICK_PERIOD_MS);
            printf("El coche esa cruzando\n");
            vTaskDelay (500 / portTICK_PERIOD_MS);
            printf("El coche termino de cruzar\n");
            vTaskDelay (1500 / portTICK_PERIOD_MS);

            bandera = 1;     
            esperando = 0;      
           }
           break;
       
           case 1:
           if (bandera == 1){
            printf ("Bajando barrera\n");
            gpio_set_level(leds[2],0);
            gpio_set_level(leds[1],1);
            vTaskDelay(1000 / portTICK_PERIOD_MS);

            gpio_set_level(leds[1],0);
            gpio_set_level(leds[0],1);
            vTaskDelay (1000 / portTICK_PERIOD_MS);

            bandera = 0;
           }
           break;
        }

    }
}
}

void app_main() {
   
    handlerQueue = xQueueCreate(10, sizeof(int));

    init_gpio();
    xTaskCreate(LED_Control_Task, "LED_Control_Task", 2048, NULL, 1, NULL);
}