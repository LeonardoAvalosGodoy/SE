#include <stdio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <driver/gpio.h>
#include "esp_timer.h"


#define INPUT_PIN GPIO_NUM_17
#define LED_PIN GPIO_NUM_2

int state = 0; 
QueueHandle_t handlerQueue;
uint64_t last_time= 0;

static void IRAM_ATTR gpio_interrupt_handler(void *args){
    if (state == 0){
      state = 1;
      int pinNumber = (int)args;
      xQueueSendFromISR(handlerQueue, &pinNumber, NULL);
    }
    }
    

void LED_Control_Task(void *params){
    int pinNumber, count = 0;
    while(true){
        if (xQueueReceive(handlerQueue, &pinNumber, portMAX_DELAY))
        {
            printf("GPIO %d was pressed %d times. The status is %d\n",
                 pinNumber, count++, gpio_get_level(INPUT_PIN));
            gpio_set_level(LED_PIN, gpio_get_level(INPUT_PIN));
            vTaskDelay( 20 / portTICK_PERIOD_MS);
            state = 0;
        }
    }
}

void app_main() {
    gpio_reset_pin(LED_PIN);
    gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT);

    gpio_reset_pin(INPUT_PIN);
    gpio_set_direction(INPUT_PIN, GPIO_MODE_INPUT);
    gpio_pulldown_en(INPUT_PIN);
    gpio_pullup_dis(INPUT_PIN);
    gpio_set_intr_type(INPUT_PIN, GPIO_INTR_POSEDGE);

    handlerQueue = xQueueCreate(10, sizeof(int));
    xTaskCreate(LED_Control_Task, "LED_Control_Task", 2048, NULL, 1, NULL);

    gpio_install_isr_service(0);
    gpio_isr_handler_add(INPUT_PIN, gpio_interrupt_handler, (void *)INPUT_PIN);

}